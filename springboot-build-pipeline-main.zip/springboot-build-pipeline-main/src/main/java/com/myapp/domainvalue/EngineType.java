package com.myapp.domainvalue;

public enum EngineType {

    ELECTRIC, HYBRID, GAS;
}
