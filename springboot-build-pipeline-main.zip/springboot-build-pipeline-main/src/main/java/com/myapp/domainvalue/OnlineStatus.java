package com.myapp.domainvalue;

public enum OnlineStatus
{
    ONLINE, OFFLINE
}
